# Context validity confirmation v2

20 newly authored synthetic confirmation cases, including 10 negative controls. Labels were authored from the documented contract; candidate outputs have not been collected or used to set labels. Human review is pending. This set covers composed conditions/scopes, optional facts, timezone observations, provenance, evidence changes and untrusted evidence content. It is a small screening set and not production-representative.

The previous CV-01..20 suite is consumed and excluded. Use the same efficient model, host settings and scoring/latency gates for both arms. No full cohort execution until human approval.
