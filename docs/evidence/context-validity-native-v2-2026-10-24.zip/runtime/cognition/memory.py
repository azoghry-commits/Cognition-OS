"""Explicit, bounded project storage. No automatic writes or cross-project retrieval."""
import hashlib
import json
import re
from datetime import datetime,timezone
from pathlib import Path
from .storage import MAX_RECORD_BYTES, read_record
from .validity import check_memory, validate_applicability

class CaseStore:
    def __init__(self,workspace):
        self.root=Path(workspace).resolve(strict=True)
        if not self.root.is_dir(): raise ValueError('Workspace directory required')
        self.project_id=hashlib.sha256(str(self.root).casefold().encode()).hexdigest()[:24]
    def path(self,case_id):
        if not isinstance(case_id,str) or not re.fullmatch(r'[a-z0-9][a-z0-9-]{0,63}',case_id): raise ValueError('Invalid case id')
        if case_id.upper() in {'CON','PRN','AUX','NUL',*(f'COM{i}' for i in range(1,10)),*(f'LPT{i}' for i in range(1,10))}: raise ValueError('Reserved device name')
        base=self.root/'.cognition'/'cases'
        target=base/(case_id+'.json')
        if not target.resolve().is_relative_to(self.root): raise ValueError('Storage path escapes project')
        # Reject symlinks and Windows junctions, including ancestors.
        for p in [self.root/'.cognition',base,target]:
            if p.is_symlink() or (hasattr(p,'is_junction') and p.is_junction()): raise ValueError('Linked storage paths are forbidden')
        return target
    def save(self,case_id,record,authorized=False,sensitive=False,sensitive_authorized=False):
        if authorized is not True: raise ValueError('Explicit persistence authorization required')
        if sensitive and sensitive_authorized is not True: raise ValueError('Explicit sensitive-data authorization required')
        if not isinstance(record,dict) or not record.get('title') or not record.get('classification'): raise ValueError('Case title and knowledge classification required')
        if record['classification'] not in ['approved_knowledge','hypothesis','observed_outcome','user_preference']: raise ValueError('Invalid knowledge classification')
        if 'applicability' in record: validate_applicability(record['applicability'])
        encoded=json.dumps(record,ensure_ascii=False,allow_nan=False)
        if len(encoded.encode())>1000000: raise ValueError('Case exceeds 1 MB limit')
        p=self.path(case_id);p.parent.mkdir(parents=True,exist_ok=True)
        # Exclusive create prevents accidental overwrite. Versions receive new IDs.
        data={'schema_version':'1.0','version':1,'project_id':self.project_id,'created_at':datetime.now(timezone.utc).isoformat(),'sensitive':bool(sensitive),'record':record}
        serialized=json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)
        if len(serialized.encode('utf-8')) > MAX_RECORD_BYTES:
            raise ValueError('Case envelope exceeds 1 MB limit')
        with p.open('x',encoding='utf-8',newline='\n') as stream: stream.write(serialized)
        return {'id':case_id,'path':str(p),'project_id':self.project_id}
    def get(self,case_id):
        data=read_record(self.path(case_id))
        if data.get('project_id')!=self.project_id: raise ValueError('Cross-project case rejected')
        return data
    def list(self,query='',context=None,status=None,now=None):
        if status is not None and (context is None or status not in ['applicable','unknown','needs_review','contradicted']):
            raise ValueError('Validity filter requires context and a known status')
        p=self.path('probe').parent
        if not p.exists():return []
        result=[]
        for f in sorted(p.glob('*.json')):
            data=self.get(f.stem)
            if query.casefold() in data['record']['title'].casefold():
                item={'id':f.stem,'title':data['record']['title'],'classification':data['record']['classification']}
                if context is not None: item['validity']=self.check(f.stem,context,now=now)
                if status is None or item['validity']['status']==status: result.append(item)
        return result
    def check(self,case_id,context,now=None):
        if not isinstance(context,dict): raise ValueError('Context must be an object')
        scope=context.get('scope',{})
        if not isinstance(scope,dict): raise ValueError('Context scope must be an object')
        context={**context,'scope':{**scope,'project_id':self.project_id}}
        return check_memory(self.get(case_id)['record'],context,now=now)
    def delete(self,case_id,authorized=False):
        if authorized is not True: raise ValueError('Explicit deletion authorization required')
        self.get(case_id);self.path(case_id).unlink()
        return {'deleted':case_id}
